<?php 
require_once('../../conn/conn.php');

	 
	$technology=$_POST['technology'];
	$semester=$_POST['semester'];
	$shift=$_POST['shift'];
	$markType=$_POST['markType'];
	









 ?>