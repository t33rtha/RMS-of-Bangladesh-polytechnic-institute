<?php 
/**
* 
*/
class Student
{
	public $technologyId;
	public $sessionId;
	public $semester;
	public $shift;
	public $subject;
	function __construct(argument)
	{
		# code...
	}

	function getRoll($technologyId,$sessionId,$semester,$shift,$subject){
			


	}


	
}











 ?>

