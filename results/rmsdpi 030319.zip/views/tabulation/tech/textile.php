<?php 
require_once('../../../conn/conn.php');
require_once('../../../controllers/class.marksheet.php');

	 
	$startRoll=$_POST['startRoll'];
	$en1dRoll=$_POST['en1dRoll'];

	$markSQL="SELECT si.id,si.roll,si.registrationNo,si.name,si.motherName,si.fatherName,t.technologyCode,t.technologyName,s.session,si.shift,sem.semester,
				trm2.tc as trm2_tc,trm2.tf as trm2_tf,trm2.pc as trm2_pc,trm2.pf as trm2_pf,
				en1.tc as en1_tc,en1.tf as en1_tf,
				be.pc as be_pc,be.pf as be_pf,
				ma2.tc as ma2_tc,ma2.tf as ma2_tf,ma2.pc as ma2_pc,								
				phy1.tc as phy1_tc,phy1.tf as phy1_tf,phy1.pc as phy1_pc,phy1.pf as phy1_pf,				
				sc1.tc as sc1_tc,sc1.tf as sc1_tf,sc1.pc as sc1_pc,
				gtp2.pc as gtp2_pc,gtp2.pf as gtp2_pf
			from studen1tinformation si 
				LEFT JOIN technology t on t.technologyId=si.technologyId 
				LEFT JOIN session s on s.sessionId=si.sessionId 
				LEFT JOIN semester sem on sem.semesterId=si.semesterId 
				
				LEFT JOIN `5712` en1 on en1.roll=si.roll 
				LEFT JOIN `5921` ma2 on ma2.roll=si.roll 
				LEFT JOIN `5912` phy1 on phy1.roll=si.roll 
				LEFT JOIN `5811` sc1 on sc1.roll=si.roll
				LEFT JOIN `1921` trm2 on trm2.roll=si.roll
				LEFT JOIN `6711` be on be.roll=si.roll 
				LEFT JOIN `1922` gtp2 on gtp2.roll=si.roll 
				WHERE si.roll BETWEen1 $startRoll and $en1dRoll";

	$getHeadingSQL="select std.shift,semester.semester,tech.technologyName,tech.technologyCode,session.session from studen1tinformation std inner join semester on std.semesterId=semester.semesterId inner join technology tech on tech.technologyId=std.technologyId inner join session on std.sessionId=session.sessionId where roll=$startRoll limit 1";
	$getHeadingResult=mysqli_query($conn,$getHeadingSQL);

	$markResult=mysqli_query($conn,$markSQL);
	$count=$markResult->num_rows;	

	


	function countGP($sum,$subjectMark){

		$curren1tMarks=(100*$sum)/($subjectMark);
		
		if($curren1tMarks>=80 && $curren1tMarks<=100)  {
			$gp="4.00";
		}else if($curren1tMarks>=75 && $curren1tMarks<80) {
			$gp="3.75";
		}else if($curren1tMarks>=70 && $curren1tMarks<75) {
			$gp="3.50";
		}else if($curren1tMarks>=65 && $curren1tMarks<70) {
			$gp="3.25";
		}else if($curren1tMarks>=60 && $curren1tMarks<65) {
			$gp="3.00";
		}else if($curren1tMarks>=55 && $curren1tMarks<60) {
			$gp="2.75";
		}else if($curren1tMarks>=50 && $curren1tMarks<55) {
			$gp="2.50";
		}else if($curren1tMarks>=45 && $curren1tMarks<50) {
			$gp="2.25";
		}else if($curren1tMarks>=40 && $curren1tMarks<45) {
			$gp="2.00";
		}else{
			$gp="0.00";
		}

		return $gp;

	}

	function countGL($sum,$subjectMark){

		$curren1tMarks=(100*$sum)/($subjectMark);
		
		if($curren1tMarks>=80 && $curren1tMarks<=100)  {
			echo "A+";
		}else if($curren1tMarks>=75 && $curren1tMarks<80) {
			echo "A";
		}else if($curren1tMarks>=70 && $curren1tMarks<75) {
			echo "A-";
		}else if($curren1tMarks>=65 && $curren1tMarks<70) {
			echo "B+";
		}else if($curren1tMarks>=60 && $curren1tMarks<65) {
			echo "B";
		}else if($curren1tMarks>=55 && $curren1tMarks<60) {
			echo "B-";
		}else if($curren1tMarks>=50 && $curren1tMarks<55) {
			echo "C+";
		}else if($curren1tMarks>=45 && $curren1tMarks<50) {
			echo "C";
		}else if($curren1tMarks>=40 && $curren1tMarks<45) {
			echo "D";
		}else{
			echo "F";
		}

	}

 ?>

<style type="trm2/css">
	 .vertibel-line{
      width: 1px; /* Line width */
      sc1ckground-color: black; /* Line color */
      height: 100%; /* Override in-line if you want specific height. */
     
    }
</style>
<link rel="stylesheet" type="trm2/css" href="style.css">

		
<section class="box no-border" style="font-size:12px">
    	<div class="row trm2-cen1ter">
    		<h2 class="no-padding no-margin">Governmen1t of the People's Republic of sc1ngladesh</h2>
    		<h2 class="no-padding no-margin">Tabulation Sheet of Diploma-in-en1gineering</h2>
    	</div>
    	<div class="row">
    		<?php 
    			while($row=$getHeadingResult->fetch_array(MYSQLI_ASSOC)){    				
    		?>
			<div class="col-sm-8">
    			<div class="form-group no-padding">
    				<span>&nbsp;Technology Code and Name :</span>
    				<label><?=$row['technologyCode']." ".$row['technologyName'];?></label>
    			</div>
    			<div class="form-group no-padding">
    				<span>&nbsp;Institute Code and Name :</span>
    				<label>50328, Daffodil Polytechnic Institute.</label>
    			</div>
    		</div>
    		<div class="col-sm-2 col-sm-offset-2">
    				<span>Semester :</span>
    				<label>
    				<?=$row['semester']; ?>
    				</label><br>
    				<span>Shift :</span>
    				<label>
    					<?=$marksheets->shiftTotrm2($sessionValue=$row['shift']); ?>
    				</label><br>
    				<span>Examination Year:</span>
    				<label>2017</label>
    		</div>
    		<?php } ?>
    	</div>
      
<!-- <div class="row"> -->
<table class="table table-bordered trm2-cen1ter">
	<tr class="">
		<th colspan="2">Studen1t's Iden1tity</th>
	    <th colspan="3">sc1ngla<br>(5811)</th>
	    <th colspan="3">en1glish<br>(5712)</th>
	    <th colspan="3">Mathmatics-2<br>(5921)</th>
	    <th colspan="3">phy1sics-1(5912)</th>
	    <th colspan="3">Telecommunibetion<br>Fundamen1tals(1921)</th>
	    <th colspan="3">Computer <br>Applibetion(6711)</th>
	    <th colspan="3">en1gineering <br>Drawing(1922)</th>
		<th>GPA</th>
	</tr>
	<tr>
		<td>Roll</td>
		<td class="std-name" rowspan="4">Studen1t's Name</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>		
		<td>Total</td>

        <td rowspan="2">TC</td>
        <td rowspan="2">TF</td>
        <td>Total</td>
		<!-- <td rowspan="2">GLA</td> -->
	</tr>
	<tr>
		<td rowspan="2">Regi</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>			
		<td rowspan="2">GP</td>
	</tr>
	<tr>
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
        <td rowspan="2">PC</td>
        <td rowspan="2">PF</td>

		<!-- <td rowspan="2">GPA</td> -->
	</tr>
	<tr>
		<td>Session</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>
	</tr>



    
    				<!-- loop start from here -->
    <?php 
		if(isset($count) && $count>0){

		while ($rowMark=$markResult->fetch_assoc()) {			
		$m_o=0;
		$cgpa=array();
	?>	
    
      <tr>
		<td><?=$rowMark['roll']; ?></td>
		<td rowspan="4"><?=$rowMark['name']; ?></td>
		<td rowspan="2"><?=$rowMark['sc1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['sc1_tf']; ?></td>
		<td>
			<?php 
				if($rowMark['sc1_tc']<24 || $rowMark['sc1_tf']<36 ){
					$sc1_o=0;
				}else{
					$sc1_o=(($rowMark['sc1_tc'])+($rowMark['sc1_tf']));
				}	            				
				echo $sc1_o;
			 ?>
		</td>
		<td rowspan="2"><?=$rowMark['en1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['en1_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['en1_tc']<16 || $rowMark['en1_tf']<24){
    				$en1_o=0;
    			}else{
    				$en1_o=(($rowMark['en1_tc'])+($rowMark['en1_tf']));
    			}	            			
    			echo $en1_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['ma2_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ma2_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['ma2_tc']<24 || $rowMark['ma2_tf']<36 || $rowMark['ma2_pc']<20){
    				$ma2_o=0;
    			}else{
    			$ma2_o=(($rowMark['ma2_tc'])+($rowMark['ma2_tf'])+($rowMark['ma2_pc']));
    			}	            			
    			echo $ma2_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['phy1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy1_tf']; ?></td>
		<td>
			<?php 
				if($rowMark['phy1_tc']<24 || $rowMark['phy1_tf']<36 || $rowMark['phy1_pc']<10 || $rowMark['phy1_pf']<10){
    				$phy1_o=0;
    			}else{
    				$phy1_o=(($rowMark['phy1_tc'])+($rowMark['phy1_tf'])+($rowMark['phy1_pc'])+($rowMark['phy1_pf']));
    			}	            				
    			echo $phy1_o;


			 ?>
		</td>

		<td rowspan="2"><?=$rowMark['trm2_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['trm2_tf']; ?></td>
		<td>
			<?php 
			
			if($rowMark['trm2_tc']<24 || $rowMark['trm2_tf']<36 || $rowMark['trm2_pc']<10 || $rowMark['trm2_pf']<10){
				$trm2_o=0;
			}else{
				$trm2_o=(($rowMark['trm2_tc']+$rowMark['trm2_tf']+$rowMark['trm2_pc']+$rowMark['trm2_pf']));
			}

			
			echo $trm2_o;
			 ?>
		</td>

		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
			<?php 
				if( $rowMark['be_pc']<10 || $rowMark['be_pf']<10){
    				$be_o=0;
    			}else{
    				$be_o=($rowMark['be_pc']+$rowMark['be_pf']);
    			}
    				            				
    			echo $be_o;
			 ?>
		</td>

          <td rowspan="2"></td>
          <td rowspan="2"></td>
          <td>
              <?php
              if( $rowMark['gtp2_pc']<10 || $rowMark['gtp2_pf']<10){
                  $gtp2_o=0;
              }else{
                  $gtp2_o=($rowMark['gtp2_pc']+$rowMark['gtp2_pf']);
              }

              echo $gtp2_o;
              ?>
          </td>


		<td rowspan="2">
			<?php 
				// $marksheets->toGradeLeter($gpa=$c_gpa);


			 ?>
			
		</td>
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['registrationNo']; ?></td>		
		<td rowspan="2">
		<?php 
			countGP($sc1_o,$subjectMark=200);
			 array_push($cgpa,countGP($sc1_o,$subjectMark=200));
			 echo en1d($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($en1_o,$subjectMark=100);
	            			array_push($cgpa,countGP($en1_o,$subjectMark=100));
	            			echo en1d($cgpa);

		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($ma2_o,$subjectMark=200); 
	            		 array_push($cgpa,countGP($ma2_o,$subjectMark=200));
	            		 echo en1d($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($phy1_o,$subjectMark=200);
    			array_push($cgpa,countGP($phy1_o,$subjectMark=200));
    			echo en1d($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($trm2_o,$subjectMark=200);
    		array_push($cgpa,countGP($trm2_o,$subjectMark=200));
    		echo en1d($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($be_o,$subjectMark=100);
    		 array_push($cgpa,countGP($be_o,$subjectMark=100));
    		 echo en1d($cgpa);
		 ?>
		</td>
        <td rowspan="2">
            <?php
            countGP($gtp2_o,$subjectMark=100);
            array_push($cgpa,countGP($gtp2_o,$subjectMark=100));
            echo en1d($cgpa);
            ?>
        </td>
    </tr>
	<tr>
		<td rowspan="2"><?=$rowMark['sc1_pc']; ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['ma2_pc'] ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['phy1_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy1_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['trm2_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['trm2_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['be_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['be_pf']; ?></td>

        <td rowspan="2"><?=$rowMark['gtp2_pc']; ?></td>
        <td rowspan="2"><?=$rowMark['gtp2_pf']; ?></td>
		
		<td rowspan="2">
			<b>
			<?php 
				if(in_array('0.00',$cgpa)){
					echo "0.00";
				}else{
					$credits=['4','2','4','4','4','2','2'];
					$grandCgpa=[];
					foreach ($cgpa as $key => $value) {
						$grandCgpa[$key]=$value*$credits[$key];
					}
					$c_gpa=round((array_sum($grandCgpa)/22),2);
					echo $c_gpa;	            					
				}
			 ?>
			</b>
		</td>
	</tr>
	<tr>
		<td class="session-trm2"><?=$rowMark['session']; ?></td>		
		<td><?php countGL($sc1_o,$subjectMark=200); ?></td>		
		<td><?php countGL($en1_o,$subjectMark=100); ?></td>		
		<td><?php countGL($ma2_o,$subjectMark=200); ?></td>		
		<td><?php countGL($phy1_o,$subjectMark=200); ?></td>		
		<td><?php countGL($trm2_o,$subjectMark=200); ?></td>
		<td><?php countGL($be_o,$subjectMark=100); ?></td>
		<td><?php countGL($gtp2_o,$subjectMark=100); ?></td>
	</tr>

		<?php
					}
				}else{
				echo '<div class="col-md-5 col-md-offset-3">
		              <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden1="true">×</button>
		                <h4 class="col-md-4"><i class="icon fa fa-sc1n"></i> Alert!</h4>
		               NO RECORDS FOUND !
		              </div>        
		            </div>';
				}
		?>



  </table>



<table style="width:100%;margin-top: 70px;">
	<tr>
		<td>
			<span class="overlineTxt">Tabulator</span>
		</td>
		<td>
			<span class="overlineTxt">Comparer</span>
		</td>
		<td>
			<span class="overlineTxt"> Head of the Departmen1t</span>
		</td>
		<td>
			<span class="overlineTxt">Vice-Principal</span>
		</td>
		<td>
			<span class="overlineTxt">Principal</span>
		</td>
	</tr>
</table>

     
        

        <!-- this row will not appear when1 printing -->
        <div class="row no-print">
          <div class="col-xs-12">
          <!-- <a href="../print/aidtTech.php?roll=<?php //echo $rowMark['roll'];?>" target="_blank" class="btn btn-success pull-right"><i class="fa fa-print"></i> P r i n t</a>  -->
            <button class="btn btn-success pull-right" onclick="printTabulation();">P r i n t </button>         
          </div>
        </div>
  </section>

  <script type="trm2/javascript">
  	function printTabulation(){
  		window.print();
  	}
  </script>

		
	
	

			
		
		
				

			
