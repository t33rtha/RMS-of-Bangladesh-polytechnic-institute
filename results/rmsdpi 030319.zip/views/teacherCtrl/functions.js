
$('#example tbody').on( 'click', '.deleteItem', function () {

    if(confirm("are you sure want to delete?")==true){
        
         var dData={"id":$(this).closest('tr').attr('id')}
       
        $.ajax({
            url:"dItem.php",
            type:"POST",
            data:dData,
            async:true,
            success:function(){
                location.reload();
            }
        });
    }

});

