<?php 
require_once('../../../conn/conn.php');
require_once('../../../controllers/class.marksheet.php');

	 
	$startRoll=$_POST['startRoll'];
	$endRoll=$_POST['endRoll'];

	$markSQL="SELECT si.id,si.roll,si.registrationNo,si.name,si.motherName,si.fatherName,t.technologyCode,t.technologyName,s.session,si.shift,sem.semester,

				rcc.tc as rcc_tc,rcc.tf as rcc_tf,rcc.pc as rcc_pc,rcc.pf as rcc_pf,
				eef.tc as eef_tc,eef.tf as eef_tf,eef.pc as eef_pc,eef.pf as eef_pf,
				ca.pc as ca_pc,ca.pf as ca_pf,
				math3.tc as math3_tc,math3.tf as math3_tf,math3.pc as math3_pc,
				chem.tc as chem_tc,chem.tf as chem_tf,chem.pc as chem_pc,chem.pf as chem_pf,
				pels.pc as pels_pc,pels.pf as pels_pf				

			from studentinformation si 
				LEFT JOIN technology t on t.technologyId=si.technologyId 
				LEFT JOIN session s on s.sessionId=si.sessionId 
				LEFT JOIN semester sem on sem.semesterId=si.semesterId 

				LEFT JOIN `67231` rcc on rcc.roll=si.roll
				LEFT JOIN `66822` eef on eef.roll=si.roll 
				LEFT JOIN `66611` ca on ca.roll=si.roll
				LEFT JOIN `65931` math3 on math3.roll=si.roll 
				LEFT JOIN `65913` chem on chem.roll=si.roll
				LEFT JOIN `65812` pels on pels.roll=si.roll				

				WHERE si.roll BETWEEN $startRoll and $endRoll";

$getHeadingSQL="select std.shift,semester.semester,tech.technologyName,tech.technologyCode,session.session from studentinformation std inner join semester on std.semesterId=semester.semesterId inner join technology tech on tech.technologyId=std.technologyId inner join session on std.sessionId=session.sessionId where roll=$startRoll limit 1";
$getHeadingResult=mysqli_query($conn,$getHeadingSQL);


	$markResult=mysqli_query($conn,$markSQL);
	$count=$markResult->num_rows;	

	


	function countGP($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			$gp="4.00";
		}else if($currentMarks>=75 && $currentMarks<80) {
			$gp="3.75";
		}else if($currentMarks>=70 && $currentMarks<75) {
			$gp="3.50";
		}else if($currentMarks>=65 && $currentMarks<70) {
			$gp="3.25";
		}else if($currentMarks>=60 && $currentMarks<65) {
			$gp="3.00";
		}else if($currentMarks>=55 && $currentMarks<60) {
			$gp="2.75";
		}else if($currentMarks>=50 && $currentMarks<55) {
			$gp="2.50";
		}else if($currentMarks>=45 && $currentMarks<50) {
			$gp="2.25";
		}else if($currentMarks>=40 && $currentMarks<45) {
			$gp="2.00";
		}else{
			$gp="0.00";
		}

		return $gp;

	}

	function countGL($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			echo "A+";
		}else if($currentMarks>=75 && $currentMarks<80) {
			echo "A";
		}else if($currentMarks>=70 && $currentMarks<75) {
			echo "A-";
		}else if($currentMarks>=65 && $currentMarks<70) {
			echo "B+";
		}else if($currentMarks>=60 && $currentMarks<65) {
			echo "B";
		}else if($currentMarks>=55 && $currentMarks<60) {
			echo "B-";
		}else if($currentMarks>=50 && $currentMarks<55) {
			echo "C+";
		}else if($currentMarks>=45 && $currentMarks<50) {
			echo "C";
		}else if($currentMarks>=40 && $currentMarks<45) {
			echo "D";
		}else{
			echo "F";
		}

	}

 ?>

<style type="text/css">
	 .vertical-line{
      width: 1px; /* Line width */
      background-color: black; /* Line color */
      height: 100%; /* Override in-line if you want specific height. */
     
    }
</style>
<link rel="stylesheet" type="text/css" href="style.css">

		
<section class="box no-border" style="font-size:12px">
    	<div class="row text-center">
    		<h2 class="no-padding no-margin">Government of the People's Republic of Bangladesh</h2>
    		<h2 class="no-padding no-margin">Tabulation Sheet of Diploma-in-Engineering</h2>
    	</div>
    	<div class="row">
    		<?php 
    			while($row=$getHeadingResult->fetch_array(MYSQLI_ASSOC)){    				
    		?>
			<div class="col-sm-8">
    			<div class="form-group no-padding">
    				<span>&nbsp;Technology Code and Name :</span>
    				<label><?=$row['technologyCode']." ".$row['technologyName'];?></label>
    			</div>
    			<div class="form-group no-padding">
    				<span>&nbsp;Institute Code and Name :</span>
    				<label>12053 Thakurgaon Polytechnic Institute, Thakurgaon.</label>
    			</div>
    		</div>
    		<div class="col-sm-2 col-sm-offset-2">
    				<span>Semester :</span>
    				<label>
    				<?=$row['semester']; ?>
    				</label><br>
    				<span>Shift :</span>
    				<label>
    					<?=$marksheets->shiftTotext($sessionValue=$row['shift']); ?>
    				</label><br>
    				<span>Examination Year:</span>
    				<label>2017</label>
    		</div>
    		<?php } ?>
    	</div>
      
<!-- <div class="row"> -->
<table class="table table-bordered text-center">
	<tr class="">
		<th colspan="2">Student's Identity</th>
		<th colspan="3">Refrigeration cycles &<br>Components(67231)</th>
		 <th colspan="3">Electronic Engineering <br>Fundamentals(66822)</th>
		 <th colspan="3">Computer Application<br>(66611)</th>	    
	    <th colspan="3">Mathmetics-3<br>(65931)</th>
	     <th colspan="3">Chemistry<br>(65913)</th>	    
	    <th colspan="3">Physical Educatino&<br>Life Skill Dev.(65812)</th>
		<th>GPA</th>
	</tr>
	<tr>
		<td>Roll</td>
		<td class="std-name" rowspan="4">Student's Name</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>	

		<td>Total</td>
		<td rowspan="2"></td>
	</tr>
	<tr>
		<td rowspan="2">Regi</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>			
	</tr>
	<tr>
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>	

		<!-- <td rowspan="2">GPA</td> -->
	</tr>
	<tr>
		<td>Session</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td></td>		
	</tr>



    
    				<!-- loop start from here -->
    <?php 
		if(isset($count) && $count>0){

		while ($rowMark=$markResult->fetch_assoc()) {			
		$m_o=0;
		$cgpa=array();
	?>	
    
      <tr>
		<td><?=$rowMark['roll']; ?></td>
		<td rowspan="4"><?=$rowMark['name']; ?></td>
		<td rowspan="2"><?=$rowMark['rcc_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['rcc_tf']; ?></td>
		<td>
			<?php 

				if($rowMark['rcc_tc']<24 || $rowMark['rcc_tf']<36|| $rowMark['rcc_pc']<10 || $rowMark['rcc_pf']<10){
        				$rcc_o=0;
        			}else{
        				$rcc_o=(($rowMark['rcc_tc'])+($rowMark['rcc_tf'])+($rowMark['rcc_pc'])+($rowMark['rcc_pf']));
        			}	            				
        			echo $rcc_o;
			
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['eef_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['eef_tf']; ?></td>
		<td>
		<?php 
				if($rowMark['eef_tc']<16 || $rowMark['eef_tf']<24 || $rowMark['eef_pc']<10 || $rowMark['eef_pf']<10){
        				$eef_o=0;
        			}else{
        				$eef_o=(($rowMark['eef_tc'])+($rowMark['eef_tf'])+($rowMark['eef_pc'])+($rowMark['eef_pf']));
        			}
        				            				
        			echo $eef_o;
		 ?>
		</td>
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
		<?php 
			if($rowMark['ca_pc']<20 || $rowMark['ca_pf']<20){
        				$ca_o=0;
        			}else{
        				$ca_o=(($rowMark['ca_pc'])+($rowMark['ca_pf']));
        			}	            			
        			echo $ca_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['math3_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['math3_tf']; ?></td>
		<td>
			<?php 
				if($rowMark['math3_tc']<24 || $rowMark['math3_tf']<36 || $rowMark['math3_pc']<20){
    					$math3_o=0;
    				}else{
    					$math3_o=($rowMark['math3_tc']+$rowMark['math3_tf']+$rowMark['math3_pc']);
    				}
    				
    				echo $math3_o;


			 ?>
		</td>

		
		<td rowspan="2"><?=$rowMark['chem_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['chem_tf']; ?></td>		
			<td>
				<?php 
				if($rowMark['chem_tc']<24 || $rowMark['chem_tf']<36 || $rowMark['chem_pc']<10 || $rowMark['chem_pf']<10){
        				$chem_o=0;
        			}else{
        				$chem_o=(($rowMark['chem_tc'])+($rowMark['chem_tf'])+($rowMark['chem_pc'])+($rowMark['chem_pf']));
        			}	            				
        			echo $chem_o;
	            				
				 ?>
			</td>




		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
			<?php 
			if($rowMark['pels_pc']<10 || $rowMark['pels_pf']<10){
    				$pels_o=0;
    			}else{
    				$pels_o=(($rowMark['pels_pc'])+($rowMark['pels_pf']));
    			}	            			
    			echo $pels_o;
			 ?>
		</td>

		

		

		<td rowspan="2">
			<?php 
				// $marksheets->toGradeLeter($gpa=$c_gpa);


			 ?>
			
		</td>
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['registrationNo']; ?></td>		
		<td rowspan="2">
		<?php 
			countGP($rcc_o,$subjectMark=200);
			 array_push($cgpa,countGP($rcc_o,$subjectMark=200));
			 echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($eef_o,$subjectMark=150);
	            			array_push($cgpa,countGP($eef_o,$subjectMark=150));
	            			echo end($cgpa);

		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($ca_o,$subjectMark=100); 
	            		 array_push($cgpa,countGP($ca_o,$subjectMark=100));
	            		 echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($math3_o,$subjectMark=200);
    			array_push($cgpa,countGP($math3_o,$subjectMark=200));
    			echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($chem_o,$subjectMark=200); 
    		array_push($cgpa,countGP($chem_o,$subjectMark=200));
    		echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($pels_o,$subjectMark=50);
    		 array_push($cgpa,countGP($pels_o,$subjectMark=50));
    		 echo end($cgpa);
		 ?>
		</td>
					
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['rcc_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['rcc_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['eef_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['eef_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ca_pc'] ?></td>
		<td rowspan="2"><?=$rowMark['ca_pf'] ?></td>
		
		<td rowspan="2"><?=$rowMark['math3_pc']; ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['chem_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['chem_pf']; ?></td>		
		
		<td rowspan="2"><?=$rowMark['pels_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['pels_pf']; ?></td>		
		
		<td rowspan="2">
			<b>
			<?php 
				if(in_array('0.00',$cgpa)){
					echo "0.00";
				}else{
					$credits=['4','3','2','4','4','1'];
					$grandCgpa=[];
					foreach ($cgpa as $key => $value) {
						$grandCgpa[$key]=$value*$credits[$key];
					}
					$c_gpa=round((array_sum($grandCgpa)/18),2);
					echo $c_gpa;	            					
				}
			 ?>
			</b>
		</td>
	</tr>
	<tr>
		<td class="session-text"><?=$rowMark['session']; ?></td>		
		<td><?php countGL($rcc_o,$subjectMark=200); ?></td>		
		<td><?php countGL($eef_o,$subjectMark=150); ?></td>		
		<td><?php countGL($ca_o,$subjectMark=100); ?></td>		
		<td><?php countGL($math3_o,$subjectMark=200); ?></td>		
		<td><?php countGL($chem_o,$subjectMark=200); ?></td>		
		<td><?php countGL($pels_o,$subjectMark=50); ?></td>		
	</tr>

		<?php 
					}
				}else{
				echo '<div class="col-md-5 col-md-offset-3">
		              <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                <h4 class="col-md-4"><i class="icon fa fa-ban"></i> Alert!</h4>
		               NO RECORDS FOUND !
		              </div>        
		            </div>';
				}
		?>



  </table>



<table style="width:100%;margin-top: 70px;">
	<tr>
		<td>
			<span class="overlineTxt">Tabulator</span>
		</td>
		<td>
			<span class="overlineTxt">Comparer</span>
		</td>
		<td>
			<span class="overlineTxt"> Head of the Department</span>
		</td>
		<td>
			<span class="overlineTxt">Vice-Principal</span>
		</td>
		<td>
			<span class="overlineTxt">Principal</span>
		</td>
	</tr>
</table>

     
        

        <!-- this row will not appear when printing -->
        <div class="row no-print">
          <div class="col-xs-12">
          <!-- <a href="../print/aidtTech.php?roll=<?php //echo $rowMark['roll'];?>" target="_blank" class="btn btn-success pull-right"><i class="fa fa-print"></i> P r i n t</a>  -->
            <button class="btn btn-success pull-right" onclick="printTabulation();">P r i n t </button>         
          </div>
        </div>
  </section>

  <script type="text/javascript">
  	function printTabulation(){
  		window.print();
  	}
  </script>

		
	
	

			
		
		
				

			
