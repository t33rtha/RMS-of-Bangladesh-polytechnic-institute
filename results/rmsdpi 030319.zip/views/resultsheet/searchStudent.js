// function searchStudents(){
// 	var st={
// 		"technology":$('#technology').val(),
// 		"semester":$('#semester').val(),
// 		"shift":$('#shift').val(),
// 		"technology":$('#technology').val(),
// 		"subject":$( "#subject" ).val()
// 	}

// console.log(st);
// 	// $.ajax({
// 	// 		type:"POST",
// 	// 		url:"select.php",
// 	// 		data:st,
// 	// 		async:true,			
// 	// 		complete :function(data){
				

// 	// 		}
// 	// 	});








// }