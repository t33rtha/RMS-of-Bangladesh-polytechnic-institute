<?php 
require_once('../../../conn/conn.php');
require_once('../../../controllers/class.marksheet.php');

	 
	$startRoll=$_POST['startRoll'];
	$endRoll=$_POST['endRoll'];

	$markSQL="SELECT si.id,si.roll,si.registrationNo,si.name,si.motherName,si.fatherName,t.technologyCode,t.technologyName,s.session,si.shift,sem.semester,
				math3.tc as math3_tc,math3.tf as math3_tf,math3.pc as math3_pc,
				phy2.tc as phy2_tc,phy2.tf as phy2_tf,phy2.pc as phy2_pc,phy2.pf as phy2_pf, 
				ce.tc as ce_tc,ce.tf as ce_tf,ce.pc as ce_pc,
				fus.tc as fus_tc,fus.tf as fus_tf,fus.pc as fus_pc,fus.pf as fus_pf,		
				ides1.tc as ides1_tc,ides1.tf as ides1_tf,ides1.pc as ides1_pc,ides1.pf as ides1_pf,
				igrap.tc as igrap_tc,igrap.tf as igrap_tf,igrap.pc as igrap_pc,igrap.pf as igrap_pf,
				ca.pc as ca_pc,ca.pf as ca_pf

			from studentinformation si 
				LEFT JOIN technology t on t.technologyId=si.technologyId 
				LEFT JOIN session s on s.sessionId=si.sessionId 
				LEFT JOIN semester sem on sem.semesterId=si.semesterId 

				LEFT JOIN `65931` math3 on math3.roll=si.roll 
				LEFT JOIN `65922` phy2 on phy2.roll=si.roll
				LEFT JOIN `65722` ce on ce.roll=si.roll 
				LEFT JOIN `66435` fus on fus.roll=si.roll 
				LEFT JOIN `68731` ides1 on ides1.roll=si.roll
				LEFT JOIN `68732` igrap on igrap.roll=si.roll 				
				LEFT JOIN `66611` ca on ca.roll=si.roll 

				WHERE si.roll BETWEEN $startRoll and $endRoll";

$getHeadingSQL="select std.shift,semester.semester,tech.technologyName,tech.technologyCode,session.session from studentinformation std inner join semester on std.semesterId=semester.semesterId inner join technology tech on tech.technologyId=std.technologyId inner join session on std.sessionId=session.sessionId where roll=$startRoll limit 1";
	$getHeadingResult=mysqli_query($conn,$getHeadingSQL);


	$markResult=mysqli_query($conn,$markSQL);
	$count=$markResult->num_rows;	

	


	function countGP($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			$gp="4.00";
		}else if($currentMarks>=75 && $currentMarks<80) {
			$gp="3.75";
		}else if($currentMarks>=70 && $currentMarks<75) {
			$gp="3.50";
		}else if($currentMarks>=65 && $currentMarks<70) {
			$gp="3.25";
		}else if($currentMarks>=60 && $currentMarks<65) {
			$gp="3.00";
		}else if($currentMarks>=55 && $currentMarks<60) {
			$gp="2.75";
		}else if($currentMarks>=50 && $currentMarks<55) {
			$gp="2.50";
		}else if($currentMarks>=45 && $currentMarks<50) {
			$gp="2.25";
		}else if($currentMarks>=40 && $currentMarks<45) {
			$gp="2.00";
		}else{
			$gp="0.00";
		}

		return $gp;

	}

	function countGL($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			echo "A+";
		}else if($currentMarks>=75 && $currentMarks<80) {
			echo "A";
		}else if($currentMarks>=70 && $currentMarks<75) {
			echo "A-";
		}else if($currentMarks>=65 && $currentMarks<70) {
			echo "B+";
		}else if($currentMarks>=60 && $currentMarks<65) {
			echo "B";
		}else if($currentMarks>=55 && $currentMarks<60) {
			echo "B-";
		}else if($currentMarks>=50 && $currentMarks<55) {
			echo "C+";
		}else if($currentMarks>=45 && $currentMarks<50) {
			echo "C";
		}else if($currentMarks>=40 && $currentMarks<45) {
			echo "D";
		}else{
			echo "F";
		}

	}

 ?>

<style type="text/css">
	 .vertical-line{
      width: 1px; /* Line width */
      background-color: black; /* Line color */
      height: 100%; /* Override in-line if you want specific height. */
     
    }
</style>
<link rel="stylesheet" type="text/css" href="style.css">

		
<section class="box no-border" style="font-size:12px">
    	<div class="row text-center">
    		<h2 class="no-padding no-margin">Government of the People's Republic of Bangladesh</h2>
    		<h2 class="no-padding no-margin">Tabulation Sheet of Diploma-in-Engineering</h2>
    	</div>
    	<div class="row">
    		<?php 
    			while($row=$getHeadingResult->fetch_array(MYSQLI_ASSOC)){    				
    		?>
			<div class="col-sm-8">
    			<div class="form-group no-padding">
    				<span>&nbsp;Technology Code and Name :</span>
    				<label><?=$row['technologyCode']." ".$row['technologyName'];?></label>
    			</div>
    			<div class="form-group no-padding">
    				<span>&nbsp;Institute Code and Name :</span>
    				<label>12053 Thakurgaon Polytechnic Institute, Thakurgaon.</label>
    			</div>
    		</div>
    		<div class="col-sm-2 col-sm-offset-2">
    				<span>Semester :</span>
    				<label>
    				<?=$row['semester']; ?>
    				</label><br>
    				<span>Shift :</span>
    				<label>
    					<?=$marksheets->shiftTotext($sessionValue=$row['shift']); ?>
    				</label><br>
    				<span>Examination Year:</span>
    				<label>2017</label>
    		</div>
    		<?php } ?>
    	</div>
      
<!-- <div class="row"> -->
<table class="table table-bordered text-center">
	<tr class="">
		<th colspan="2">Student's Identity</th>
	    <th colspan="3">Mathmetics-3<br>(65931)</th>
	    <th colspan="3">Physics-2<br>(65922)</th>
	    <th colspan="3">Communicative English<br>(65722)</th>
	    <th colspan="3">Fundamental Surveying<br>(66435)</th>
	    <th colspan="3">Interior Design-1<br>(68731)</th>
	    <th colspan="3">Interior <br>Graphics(68732)</th>	    
	    <th colspan="3">Computer Application<br>(66611)</th>	    
		<th>GPA</th>
	</tr>
	<tr>
		<td>Roll</td>
		<td class="std-name" rowspan="4">Student's Name</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>		
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>		
		<td>Total</td>
		<td rowspan="2"></td>
	</tr>
	<tr>
		<td rowspan="2">Regi</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>			
		<td rowspan="2">GP</td>			
	</tr>
	<tr>
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>	

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>		
		<!-- <td rowspan="2">GPA</td> -->
	</tr>
	<tr>
		<td>Session</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td></td>		
	</tr>



    
    				<!-- loop start from here -->
    <?php 
		if(isset($count) && $count>0){

		while ($rowMark=$markResult->fetch_assoc()) {			
		$m_o=0;
		$cgpa=array();
	?>	
    
      <tr>
		<td><?=$rowMark['roll']; ?></td>
		<td rowspan="4"><?=$rowMark['name']; ?></td>
		<td rowspan="2"><?=$rowMark['math3_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['math3_tf']; ?></td>
		<td>
			<?php 

				if($rowMark['math3_tc']<24 || $rowMark['math3_tf']<36 || $rowMark['math3_pc']<20){
					$ma_o=0;
				}else{
					$ma_o=($rowMark['math3_tc']+$rowMark['math3_tf']+$rowMark['math3_pc']);
				}
				
				echo $ma_o;
			
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['phy2_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy2_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['phy2_tc']<24 || $rowMark['phy2_tf']<36 || $rowMark['phy2_pc']<10 || $rowMark['phy2_pf']<10){
				$phy2_o=0;
			}else{
				$phy2_o=(($rowMark['phy2_tc'])+($rowMark['phy2_tf'])+($rowMark['phy2_pc'])+($rowMark['phy2_pf']));
			}	            				
			echo $phy2_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['ce_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ce_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['ce_tc']<8 || $rowMark['ce_tf']<12 || $rowMark['ce_pc']<20){
				$ce_o=0;
			}else{
				$ce_o=(($rowMark['ce_tc'])+($rowMark['ce_tf'])+($rowMark['ce_pc']));
			}	            				
			echo $ce_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['fus_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['fus_tf']; ?></td>
		<td>
			<?php 
				if($rowMark['fus_tc']<24 || $rowMark['fus_tf']<36 || $rowMark['fus_pc']<10 || $rowMark['fus_pf']<10){
    				$fus_o=0;
    			}else{
    				$fus_o=(($rowMark['fus_tc'])+($rowMark['fus_tf'])+($rowMark['fus_pc'])+($rowMark['fus_pf']));
    			}	            			
    			echo $fus_o;


			 ?>
		</td>

		<td rowspan="2"><?=$rowMark['ides1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ides1_tf']; ?></td>
		<td>
			<?php 
			
			if($rowMark['ides1_tc']<16 || $rowMark['ides1_tf']<24 || $rowMark['ides1_pc']<10 || $rowMark['ides1_pf']<10){
				$ides1_o=0;
			}else{
				$ides1_o=(($rowMark['ides1_tc'])+($rowMark['ides1_tf'])+($rowMark['ides1_pc'])+($rowMark['ides1_pf']));
			}	            				
			echo $ides1_o;
			 ?>
		</td>

		<td rowspan="2"><?=$rowMark['igrap_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['igrap_tf']; ?></td>		
		<td>
			<?php 
			if($rowMark['igrap_tc']<8 || $rowMark['igrap_tf']<12 || $rowMark['igrap_pc']<10 || $rowMark['igrap_pf']<10){
        					$igrap_o=0;
        				}else{
        					$igrap_o=(($rowMark['igrap_tc'])+($rowMark['igrap_tf'])+($rowMark['igrap_pc'])+($rowMark['igrap_pf']));
        				}	            				
        				echo $igrap_o;
			 ?>
		</td>

		<td rowspan="2"></td>
		<td rowspan="2"></td>		
		<td>
			<?php 
			if($rowMark['ca_pc']<20 || $rowMark['ca_pf']<20){
				$ca_o=0;
			}else{
				$ca_o=(($rowMark['ca_pc'])+($rowMark['ca_pf']));
			}	            			
			echo $ca_o;
			 ?>
		</td>

		<td rowspan="2">
			<?php 
				// $marksheets->toGradeLeter($gpa=$c_gpa);


			 ?>
			
		</td>
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['registrationNo']; ?></td>		
		<td rowspan="2">
		<?php 
			countGP($ma_o,$subjectMark=200);
			 array_push($cgpa,countGP($ma_o,$subjectMark=200));
			 echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($phy2_o,$subjectMark=200);
	            			array_push($cgpa,countGP($phy2_o,$subjectMark=200));
	            			echo end($cgpa);

		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($ce_o,$subjectMark=100); 
	            		 array_push($cgpa,countGP($ce_o,$subjectMark=100));
	            		 echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($fus_o,$subjectMark=200);
    			array_push($cgpa,countGP($fus_o,$subjectMark=200));
    			echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($ides1_o,$subjectMark=150); 
    		array_push($cgpa,countGP($ides1_o,$subjectMark=150));
    		echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($igrap_o,$subjectMark=100);
    		 array_push($cgpa,countGP($igrap_o,$subjectMark=100));
    		 echo end($cgpa);
		 ?>
		</td>
		<td rowspan="2">
		<?php 
			countGP($ca_o,$subjectMark=100);
    		 array_push($cgpa,countGP($ca_o,$subjectMark=100));
    		 echo end($cgpa);
		 ?>
		</td>			
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['math3_pc']; ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['phy2_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy2_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ce_pc'] ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['fus_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['fus_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ides1_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['ides1_pf']; ?></td>

		<td rowspan="2"><?=$rowMark['igrap_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['igrap_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ca_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['ca_pf']; ?></td>		
		
		<td rowspan="2">
			<b>
			<?php 
				if(in_array('0.00',$cgpa)){
					echo "0.00";
				}else{
					$credits=['4','4','2','4','3','2','2'];
					$grandCgpa=[];
					foreach ($cgpa as $key => $value) {
						$grandCgpa[$key]=$value*$credits[$key];
					}
					$c_gpa=round((array_sum($grandCgpa)/21),2);
					echo $c_gpa;	            					
				}
			 ?>
			</b>
		</td>
	</tr>
	<tr>
		<td class="session-text"><?=$rowMark['session']; ?></td>		
		<td><?php countGL($ma_o,$subjectMark=200); ?></td>		
		<td><?php countGL($phy2_o,$subjectMark=200); ?></td>		
		<td><?php countGL($ce_o,$subjectMark=100); ?></td>		
		<td><?php countGL($fus_o,$subjectMark=200); ?></td>		
		<td><?php countGL($ides1_o,$subjectMark=150); ?></td>		
		<td><?php countGL($igrap_o,$subjectMark=100); ?></td>		
		<td><?php countGL($ca_o,$subjectMark=100); ?></td>		
	</tr>

		<?php 
					}
				}else{
				echo '<div class="col-md-5 col-md-offset-3">
		              <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                <h4 class="col-md-4"><i class="icon fa fa-ban"></i> Alert!</h4>
		               NO RECORDS FOUND !
		              </div>        
		            </div>';
				}
		?>



  </table>



<table style="width:100%;margin-top: 70px;">
	<tr>
		<td>
			<span class="overlineTxt">Tabulator</span>
		</td>
		<td>
			<span class="overlineTxt">Comparer</span>
		</td>
		<td>
			<span class="overlineTxt"> Head of the Department</span>
		</td>
		<td>
			<span class="overlineTxt">Vice-Principal</span>
		</td>
		<td>
			<span class="overlineTxt">Principal</span>
		</td>
	</tr>
</table>

     
        

        <!-- this row will not appear when printing -->
        <div class="row no-print">
          <div class="col-xs-12">
          <!-- <a href="../print/aidtTech.php?roll=<?php //echo $rowMark['roll'];?>" target="_blank" class="btn btn-success pull-right"><i class="fa fa-print"></i> P r i n t</a>  -->
            <button class="btn btn-success pull-right" onclick="printTabulation();">P r i n t </button>         
          </div>
        </div>
  </section>

  <script type="text/javascript">
  	function printTabulation(){
  		window.print();
  	}
  </script>

		
	
	

			
		
		
				

			
