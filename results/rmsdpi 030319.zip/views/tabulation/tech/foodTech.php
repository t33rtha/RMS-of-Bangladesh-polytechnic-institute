<?php 
require_once('../../../conn/conn.php');
require_once('../../../controllers/class.marksheet.php');

	 
	$startRoll=$_POST['startRoll'];
	$endRoll=$_POST['endRoll'];
	
	$markSQL="SELECT si.id,si.roll,si.registrationNo,si.name,si.motherName,si.fatherName,t.technologyCode,t.technologyName,s.session,si.shift,sem.semester,
				fsm.tc as fsm_tc,fsm.tf as fsm_tf,fsm.pc as fsm_pc,fsm.pf as fsm_pf,
				ca.pc as ca_pc,ca.pf as ca_pf,
				eef.tc as eef_tc,eef.tf as eef_tf,eef.pc as eef_pc,eef.pf as eef_pf,
				ss.tc as ss_tc,ss.tf as ss_tf,				
				ce.tc as ce_tc,ce.tf as ce_tf,ce.pc as ce_pc,
				ma2.tc as ma2_tc,ma2.tf as ma2_tf,ma2.pc as ma2_pc,
				phy.tc as phy_tc,phy.tf as phy_tf,phy.pc as phy_pc,phy.pf as phy_pf 
			from studentinformation si 
				LEFT JOIN technology t on t.technologyId=si.technologyId 
				LEFT JOIN session s on s.sessionId=si.sessionId 
				LEFT JOIN semester sem on sem.semesterId=si.semesterId 
				LEFT JOIN `66921` fsm on fsm.roll=si.roll 
				LEFT JOIN `66611` ca on ca.roll=si.roll 
				LEFT JOIN `66712` eef on eef.roll=si.roll 
				LEFT JOIN `65921` ma2 on ma2.roll=si.roll 
				LEFT JOIN `65912` phy on phy.roll=si.roll 
				LEFT JOIN `65811` ss on ss.roll=si.roll
				LEFT JOIN `65722` ce on ce.roll=si.roll 
				WHERE si.roll BETWEEN $startRoll and $endRoll";

	$getHeadingSQL="select std.shift,semester.semester,tech.technologyName,tech.technologyCode,session.session from studentinformation std inner join semester on std.semesterId=semester.semesterId inner join technology tech on tech.technologyId=std.technologyId inner join session on std.sessionId=session.sessionId where roll=$startRoll limit 1";
	$getHeadingResult=mysqli_query($conn,$getHeadingSQL);

	$markResult=mysqli_query($conn,$markSQL);
	$count=$markResult->num_rows;	

	

	function countGP($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			$gp="4.00";
		}else if($currentMarks>=75 && $currentMarks<80) {
			$gp="3.75";
		}else if($currentMarks>=70 && $currentMarks<75) {
			$gp="3.50";
		}else if($currentMarks>=65 && $currentMarks<70) {
			$gp="3.25";
		}else if($currentMarks>=60 && $currentMarks<65) {
			$gp="3.00";
		}else if($currentMarks>=55 && $currentMarks<60) {
			$gp="2.75";
		}else if($currentMarks>=50 && $currentMarks<55) {
			$gp="2.50";
		}else if($currentMarks>=45 && $currentMarks<50) {
			$gp="2.25";
		}else if($currentMarks>=40 && $currentMarks<45) {
			$gp="2.00";
		}else{
			$gp="0.00";
		}

		return $gp;

	}

	function countGL($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			echo "A+";
		}else if($currentMarks>=75 && $currentMarks<80) {
			echo "A";
		}else if($currentMarks>=70 && $currentMarks<75) {
			echo "A-";
		}else if($currentMarks>=65 && $currentMarks<70) {
			echo "B+";
		}else if($currentMarks>=60 && $currentMarks<65) {
			echo "B";
		}else if($currentMarks>=55 && $currentMarks<60) {
			echo "B-";
		}else if($currentMarks>=50 && $currentMarks<55) {
			echo "C+";
		}else if($currentMarks>=45 && $currentMarks<50) {
			echo "C";
		}else if($currentMarks>=40 && $currentMarks<45) {
			echo "D";
		}else{
			echo "F";
		}

	}

 ?>

<style type="text/css">
	 .vertical-line{
      width: 1px; /* Line width */
      background-color: black; /* Line color */
      height: 100%; /* Override in-line if you want specific height. */
     
    }
</style>
<link rel="stylesheet" type="text/css" href="style.css">

		
<section class="box no-border" style="font-size:12px">
    	<div class="row text-center">
    		<h2 class="no-padding no-margin">Government of the People's Republic of Bangladesh</h2>
    		<h2 class="no-padding no-margin">Tabulation Sheet of Diploma-in-Engineering</h2>
    	</div>
    	<div class="row">
    		<?php 
    			while($row=$getHeadingResult->fetch_array(MYSQLI_ASSOC)){    				
    		?>
			<div class="col-sm-8">
    			<div class="form-group no-padding">
    				<span>&nbsp;Technology Code and Name :</span>
    				<label><?php echo $row['technologyCode']." ".$row['technologyName'];?></label>
    			</div>
    			<div class="form-group no-padding">
    				<span>&nbsp;Institute Code and Name :</span>
    				<label>12053 Thakurgaon Polytechnic Institute, Thakurgaon.</label>
    			</div>
    		</div>
    		<div class="col-sm-2 col-sm-offset-2">
    				<span>Semester :</span>
    				<label>
    				<?php echo $row['semester']; ?>
    				</label><br>
    				<span>Shift :</span>
    				<label>
    					<?php echo $marksheets->shiftTotext($sessionValue=$row['shift']); ?>
    				</label><br>
    				<span>Examination Year:</span>
    				<label>2017</label>
    		</div>
    		<?php } ?>
    	</div>
      
<!-- <div class="row"> -->
<table class="table table-bordered text-center">
	<tr class="">
		<th colspan="2">Student's Identity</th>
	    <th colspan="3">Food Safety & Management<br>(66921)</th>
	    <th colspan="3">Computer Application<br>(66611)</th>
	    <th colspan="3">Electrical Engineering Fundamentals<br>(66712)</th>
	    <th colspan="3">Social Science<br>(65811)</th>
	    <th colspan="3">Communicative English<br>(65722)</th>
	    <th colspan="3">Mathmatics-2<br>(65921)</th>
	    <th colspan="3">Physics-1<br>(65912)</th>
		<th>Total &<br>GL,GP</th>
	</tr>
	<tr>
		<td>Roll</td>
		<td class="std-name" rowspan="4">Student's Name</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>		
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>		
		<td>Total</td>
		<td rowspan="2">GLA</td>
	</tr>
	<tr>
		<td rowspan="2">Regi</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>			
		<td rowspan="2">GP</td>			
	</tr>
	<tr>
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>	

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>		
		
		<td rowspan="2">GPA</td>
	</tr>
	<tr>
		<td class="session-text">Session</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
	</tr>
    
   <!-- LOOP start from here -->
    <?php 
		if(isset($count) && $count>0){

		while ($rowMark=$markResult->fetch_assoc()) {			
		// $m_o=0;
		$cgpa=array();
	?>	
    
      <tr>
		<td><?php echo $rowMark['roll']; ?></td>
		<td rowspan="4"><?php echo $rowMark['name']; ?></td>
		<td rowspan="2"><?=$rowMark['fsm_tc']?></td>
		<td rowspan="2"><?=$rowMark['fsm_tf']?></td>
		<td>
			<?php 
				if($rowMark['fsm_tc']<8 || $rowMark['fsm_tf']<12 || $rowMark['fsm_pc']<10 || $rowMark['fsm_pf']<10){
					$fsm_o=0;
				}else{
					$fsm_o=(($rowMark['fsm_tc']+$rowMark['fsm_tf']+$rowMark['fsm_pc']+$rowMark['fsm_pf']));
				}

				
				echo $fsm_o;
			 ?>
		</td>
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
		<?php 
			if($rowMark['ca_pc']<20 || $rowMark['ca_pf']<20){
    				$ca_o=0;
    			}else{
    				$ca_o=(($rowMark['ca_pc'])+($rowMark['ca_pf']));
    			}	            			
    			echo $ca_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['eef_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['eef_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['eef_tc']<24 || $rowMark['eef_tf']<36 || $rowMark['eef_pc']<10 || $rowMark['eef_pf']<10){
    				$eef_o=0;
    			}else{
    				$eef_o=(($rowMark['eef_tc'])+($rowMark['eef_tf'])+($rowMark['eef_pc'])+($rowMark['eef_pf']));
    			}
    				            				
    			echo $eef_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['ss_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ss_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['ss_tc']<24 || $rowMark['ss_tf']<36){
					$ss_o=0;
				}else{
					$ss_o=(($rowMark['ss_tc'])+($rowMark['ss_tf']));
				}	            				
				echo $ss_o;

		 ?>
		</td>

		<td rowspan="2"><?=$rowMark['ce_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ce_tf']; ?></td>
		<td>
			<?php 
			if($rowMark['ce_tc']<8 || $rowMark['ce_tf']<12 || $rowMark['ce_pc']<20){
					$ce_o=0;
				}else{
					$ce_o=(($rowMark['ce_tc'])+($rowMark['ce_tf'])+($rowMark['ce_pc']));
				}	            				
				echo $ce_o;
			 ?>
		</td>

		<td rowspan="2"><?=$rowMark['ma2_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ma2_tf']; ?></td>		
		<td>
			<?php 
				if($rowMark['ma2_tc']<24 || $rowMark['ma2_tf']<36 || $rowMark['ma2_pc']<20){
        				$ma2_o=0;
        			}else{
        			$ma2_o=(($rowMark['ma2_tc'])+($rowMark['ma2_tf'])+($rowMark['ma2_pc']));
        			}	            			
        			echo $ma2_o;
			 ?>
		</td>
		<td rowspan="2"><?=$rowMark['phy_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy_tf']; ?></td>		
		<td>
			<?php 
				if($rowMark['phy_tc']<24 || $rowMark['phy_tf']<36 || $rowMark['phy_pc']<10 || $rowMark['phy_pf']<10){
        				$phy_o=0;
        			}else{
        				$phy_o=(($rowMark['phy_tc'])+($rowMark['phy_tf'])+($rowMark['phy_pc'])+($rowMark['phy_pf']));
        			}	            				
        			echo $phy_o;
			 ?>
		</td>
		<td rowspan="2">
			<?php 
				// $marksheets->toGradeLeter($gpa=$c_gpa);
			 ?>
			
		</td>
	</tr>
	<tr>
		<td rowspan="2"><?php echo $rowMark['registrationNo']; ?></td>		
		<td rowspan="2">
		<?php 
			countGP($fsm_o,$subjectMark=100);
			array_push($cgpa,countGP($fsm_o,$subjectMark=100));
			echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($ca_o,$subjectMark=100);
			array_push($cgpa,countGP($ca_o,$subjectMark=100));
			echo end($cgpa);

		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($eef_o,$subjectMark=200); 
            		array_push($cgpa,countGP($eef_o,$subjectMark=200));
            		echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($ss_o,$subjectMark=150);
        		 array_push($cgpa,countGP($ss_o,$subjectMark=150));
        		 echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($ce_o,$subjectMark=100); 
    		 array_push($cgpa,countGP($ce_o,$subjectMark=100));
    		 echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			 countGP($ma2_o,$subjectMark=200); 
    		 array_push($cgpa,countGP($ma2_o,$subjectMark=200));
    		 echo end($cgpa);
		 ?>
		</td>	
		<td rowspan="2">
		<?php 
			 countGP($phy_o,$subjectMark=200);
    		 array_push($cgpa,countGP($phy_o,$subjectMark=200));
    		 echo end($cgpa);
		 ?>
		</td>		
	</tr>
	<tr>                              <!-- PC,pF area -->
		<td rowspan="2"><?=$rowMark['fsm_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['fsm_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ca_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['ca_pf']; ?></td>

		<td rowspan="2"><?=$rowMark['eef_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['eef_pf']; ?></td>	
		
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['ce_pc']; ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['ma2_pc']; ?></td>
		<td rowspan="2"></td>

		<td rowspan="2"><?=$rowMark['phy_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy_pc']; ?></td>		
		
		<td rowspan="2">
			<b>
			<?php 
				if(in_array('0.00',$cgpa)){
					echo "0.00";
				}else{
					$credits=['2','2','4','3','2','4','4'];
					$grandCgpa=[];
					foreach ($cgpa as $key => $value) {
						$grandCgpa[$key]=$value*$credits[$key];
					}
					$c_gpa=round((array_sum($grandCgpa)/21),2);
					echo $c_gpa;	            					
				}
			 ?>
			</b>
		</td>
	</tr>
	<tr>
		<td><?php echo $rowMark['session']; ?></td>		
		<td><?php countGL($fsm_o,$subjectMark=100); ?></td>		
		<td><?php countGL($ca_o,$subjectMark=100); ?></td>		
		<td><?php countGL($eef_o,$subjectMark=200); ?></td>		
		<td><?php countGL($ss_o,$subjectMark=150); ?></td>		
		<td><?php countGL($ce_o,$subjectMark=100); ?></td>		
		<td><?php countGL($ma2_o,$subjectMark=200); ?></td>		
		<td><?php countGL($phy_o,$subjectMark=200); ?></td>		
	</tr>

		<?php 
					}
				}else{
				echo '<div class="col-md-5 col-md-offset-3">
		              <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                <h4 class="col-md-4"><i class="icon fa fa-ban"></i> Alert!</h4>
		               NO RECORDS FOUND !
		              </div>        
		            </div>';
				}
		?>



  </table>

  <table style="width:100%;margin-top: 70px;">
	<tr>
		<td>
			<span class="overlineTxt">Tabulator</span>
		</td>
		<td>
			<span class="overlineTxt">Comparer</span>
		</td>
		<td>
			<span class="overlineTxt"> Head of the Department</span>
		</td>
		<td>
			<span class="overlineTxt">Vice-Principal</span>
		</td>
		<td>
			<span class="overlineTxt">Principal</span>
		</td>
	</tr>
</table>
  <!-- </div> end of row -->
     
        

        <!-- this row will not appear when printing -->
        <div class="row no-print">
          <div class="col-xs-12">
          
            <button class="btn btn-success pull-right" onclick="printTabulation();">P r i n t </button>         
          </div>
        </div>
  </section>

  <script type="text/javascript">
  	function printTabulation(){
  		window.print();
  	}
  </script>


	

			
		
		
				

			
