<?php 
require_once('../../../conn/conn.php');
require_once('../../../controllers/class.marksheet.php');

	 
	$startRoll=$_POST['startRoll'];
	$endRoll=$_POST['endRoll'];

	$markSQL="SELECT si.id,si.roll,si.registrationNo,si.name,si.motherName,si.fatherName,t.technologyCode,t.technologyName,s.session,si.shift,sem.semester,
				trm1.tc as trm1_tc,trm1.tf as trm1_tf,
				ch.tc as ch_tc,ch.tf as ch_tf,ch.pc as ch_pc,ch.pf as ch_pf,			
				ma1.tc as ma1_tc,ma1.tf as ma1_tf,ma1.pc as ma1_pc,	
				gtp1.tc as gtp1_tc,gtp1.tf as gtp1_tf,gtp1.pc as gtp1_pc,gtp1.pf as gtp1_pf,
				bang.tc as bang_tc,bang.tf as bang_tf,bang.pc as bang_pc,bang.pf as bang_pf,
				ed.pc as ed_pc,ed.pf as ed_pf,				
				bwp.pc as bwp_pc,bwp.pf as bwp_pf,
				pelsd.pc as pelsd_pc,pelsd.pf as pelsd_pf
			from studentinformation si 
				LEFT JOIN technology t on t.technologyId=si.technologyId 
				LEFT JOIN session s on s.sessionId=si.sessionId 
				LEFT JOIN semester sem on sem.semesterId=si.semesterId 
				LEFT JOIN `5913` ch on ch.roll=si.roll 
				LEFT JOIN `5911` ma1 on ma1.roll=si.roll 
				LEFT JOIN `5711` bang on bang.roll=si.roll 
				LEFT JOIN `7011` bwp on bwp.roll=si.roll
				
				LEFT JOIN `1011` ed on ed.roll=si.roll
				LEFT JOIN `1911` trm1 on trm1.roll=si.roll
				LEFT JOIN `1912` gtp1 on gtp1.roll=si.roll 
				LEFT JOIN `5812` pelsd on pelsd.roll=si.roll 

				WHERE si.semesterId=1 && si.roll BETWEEN $startRoll and $endRoll";

	$getHeadingSQL="select std.shift,semester.semester,tech.technologyName,tech.technologyCode,session.session from studentinformation std inner join semester on std.semesterId=semester.semesterId inner join technology tech on tech.technologyId=std.technologyId inner join session on std.sessionId=session.sessionId where roll=$startRoll limit 1";
	$getHeadingResult=mysqli_query($conn,$getHeadingSQL);

	$markResult=mysqli_query($conn,$markSQL);
	$count=$markResult->num_rows;




	function countGP($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);

		if($currentMarks>=80 && $currentMarks<=100)  {
			$gp="4.00";
		}else if($currentMarks>=75 && $currentMarks<80) {
			$gp="3.75";
		}else if($currentMarks>=70 && $currentMarks<75) {
			$gp="3.50";
		}else if($currentMarks>=65 && $currentMarks<70) {
			$gp="3.25";
		}else if($currentMarks>=60 && $currentMarks<65) {
			$gp="3.00";
		}else if($currentMarks>=55 && $currentMarks<60) {
			$gp="2.75";
		}else if($currentMarks>=50 && $currentMarks<55) {
			$gp="2.50";
		}else if($currentMarks>=45 && $currentMarks<50) {
			$gp="2.25";
		}else if($currentMarks>=40 && $currentMarks<45) {
			$gp="2.00";
		}else{
			$gp="0.00";
		}

		return $gp;

	}

	function countGL($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);

		if($currentMarks>=80 && $currentMarks<=100)  {
			echo "A+";
		}else if($currentMarks>=75 && $currentMarks<80) {
			echo "A";
		}else if($currentMarks>=70 && $currentMarks<75) {
			echo "A-";
		}else if($currentMarks>=65 && $currentMarks<70) {
			echo "B+";
		}else if($currentMarks>=60 && $currentMarks<65) {
			echo "B";
		}else if($currentMarks>=55 && $currentMarks<60) {
			echo "B-";
		}else if($currentMarks>=50 && $currentMarks<55) {
			echo "C+";
		}else if($currentMarks>=45 && $currentMarks<50) {
			echo "C";
		}else if($currentMarks>=40 && $currentMarks<45) {
			echo "D";
		}else{
			echo "F";
		}

	}

 ?>

<style type="text/css">
	 .vertibel-line{
      width: 1px; /* Line width */
      background-color: black; /* Line color */
      height: 100%; /* Override in-line if you want specific height. */

    }
</style>
<link rel="stylesheet" type="text/css" href="style.css">


<section class="box no-border" style="font-size:12px">
    	<div class="row text-center">
    		<h2 class="no-padding no-margin">Government of the People's Republic of  Bangladesh</h2>
    		<h2 class="no-padding no-margin">Tabulation Sheet of Diploma-in-engineering</h2>
    	</div>
    	<div class="row">
    		<?php
    			while($row=$getHeadingResult->fetch_array(MYSQLI_ASSOC)){
    		?>
			<div class="col-sm-8">
    			<div class="form-group no-padding">
    				<span>&nbsp;Technology Code and Name :</span>
    				<label><?=$row['technologyCode']." ".$row['technologyName'];?></label>
    			</div>
    			<div class="form-group no-padding">
    				<span>&nbsp;Institute Code and Name :</span>
    				<label>50328, Daffodil Polytechnic Institute.</label>
    			</div>
    		</div>
    		<div class="col-sm-2 col-sm-offset-2">
    				<span>Semester :</span>
    				<label>
    				<?=$row['semester']; ?>
    				</label>
<!--                    <br>-->
<!--    				<span>Shift :</span>-->
<!--    				<label>-->
    					<?php //echo $marksheets->shiftTotext($sessionValue=$row['shift']); ?>
<!--    				</label>-->
                <br>
    				<span>Examination Year:</span>
    				<label>2018</label>
    		</div>
    		<?php } ?>
    	</div>

<!-- <div class="row"> -->
<table style="font-size: 11px!important;" class="table table-bordered text-center">
	<tr class="">
		<th colspan="2">Student's Identity</th>
	    <th colspan="3">Textile Raw Material-1<br>(1911)</th>
	    <th colspan="3">Engineering Drawing <br>(1011)</th>
	    <th colspan="3">Mathmatics-1<br>(5911)</th>
	    <th colspan="3">General Textile Process-1<br>(1912)</th>
	    <th colspan="3">Basic Workshop practice >(7011)</th>
	    <th colspan="3">Chemistry<br>(5913)</th>
	    <th colspan="3">Bangla<br>(5711)</th>
	    <th colspan="3">Physical Education, <br>Life Skill Development(5812)</th>
		
		<th>Grade Point<br>Avg.</th>
		<th>Grade Letter<br>Avg.</th>
		<th>Remark</th>
		<style type="text/css">
			table.table-bordered{
			    border:2px solid #ddd;			    
			  }
			table.table-bordered > thead > tr > th{
			    border:2px solid #ddd;
			}
			table.table-bordered > tbody > tr > th{
			    border:2px solid #ddd;
			}
			table.table-bordered > tbody > tr > td{
			    border:2px solid #ddd;
			}
		</style>
	</tr>
	<tr>
		<td>Roll</td>
		<td class="std-name" rowspan="4">Student's Name</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>

        <td rowspan="2">TC</td>
        <td rowspan="2">TF</td>
        <td>Total</td>

        <td rowspan="2">TC</td>
        <td rowspan="2">TF</td>
        <td>Total</td>
		
		<td rowspan="4">GPA</td>
		<td rowspan="4">GLA</td>
		<td rowspan="4">pass<br>/fail</td>
	</tr>
	<tr>
		<td rowspan="2">Regi</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
		<td rowspan="2">GP</td>
	</tr>
	<tr>
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>

		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
        <td rowspan="2">PC</td>
        <td rowspan="2">PF</td>
        <td rowspan="2">PC</td>
        <td rowspan="2">PF</td>

		<!-- <td rowspan="2">GPA</td> -->
	</tr>
	<tr>
		<td>Session</td>
		<td>GL</td>
		<td>GL</td>
		<td>GL</td>
		<td>GL</td>
		<td>GL</td>
		<td>GL</td>
		<td>GL</td>
		<td>GL</td>
	</tr>




    				<!-- loop start from here -->
    <?php
		if(isset($count) && $count>0){

		while ($rowMark=$markResult->fetch_assoc()) {
		$m_o=0;
		$cgpa=array();
	?>

      <tr>
		<td><?=$rowMark['roll']; ?></td>
		<td rowspan="4"><?=$rowMark['name']; ?></td>
		<td rowspan="2"><?=$rowMark['trm1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['trm1_tf']; ?></td>
		<td>
			<?php
				if($rowMark['trm1_tc']<8 || $rowMark['trm1_tf']<32){
					$trm1_o=0;
				}else{
					$trm1_o=(($rowMark['trm1_tc'])+($rowMark['trm1_tf']));
				}
				echo $trm1_o;
			 ?>
		</td>
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
		<?php
			if($rowMark['ed_pc']<20 || $rowMark['ed_pf']<20){
    				$ed_o=0;
    			}else{
    				$ed_o=(($rowMark['ed_pc'])+($rowMark['ed_pf']));
    			}
    			echo $ed_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['ma1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ma1_tf']; ?></td>
		<td>
		<?php
			if($rowMark['ma1_tc']<12 || $rowMark['ma1_tf']<48 || $rowMark['ma1_pc']<20){
    				$ma1_o=0;
    			}else{
    			$ma1_o=(($rowMark['ma1_tc'])+($rowMark['ma1_tf'])+($rowMark['ma1_pc']));
    			}
    			echo $ma1_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['gtp1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['gtp1_tf']; ?></td>
		<td>
			<?php
				if($rowMark['gtp1_tc']<12 || $rowMark['gtp1_tf']<48 || $rowMark['gtp1_pc']<10 ||
                    $rowMark['gtp1_pf']<10){
    				$gtp1_o=0;
    			}else{
    				$gtp1_o=(($rowMark['gtp1_tc'])+($rowMark['gtp1_tf'])+($rowMark['gtp1_pc'])+($rowMark['gtp1_pf']));
    			}
    			echo $gtp1_o;


			 ?>
		</td>

		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
			<?php

			if($rowMark['bwp_pc']<20 || $rowMark['bwp_pf']<20){
				$bwp_o=0;
			}else{
				$bwp_o=(($rowMark['bwp_pc']+$rowMark['bwp_pf']));
			}


			echo $bwp_o;
			 ?>
		</td>

		<td rowspan="2"><?=$rowMark['ch_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ch_tf']; ?></td>
		<td>
			<?php
				if($rowMark['ch_tc']<12 || $rowMark['ch_tf']<48 || $rowMark['ch_pc']<10 || $rowMark['ch_pf']<10){
    				$ch_o=0;
    			}else{
    				$ch_o=(($rowMark['ch_tc'])+($rowMark['ch_tf'])+($rowMark['ch_pc'])+($rowMark['ch_pf']));

    			}

    			echo $ch_o;
			 ?>
		</td>

          <td rowspan="2"><?=$rowMark['bang_tc']; ?></td>
          <td rowspan="2"><?=$rowMark['bang_tf']; ?></td>
          <td>
              <?php
              if( $rowMark['bang_tc']<8 || $rowMark['bang_tf']<32 || $rowMark['bang_pc']<10 || $rowMark['bang_pf']<10){
                  $bang_o=0;
              }else{
                  $bang_o=($rowMark['bang_pc']+$rowMark['bang_pf']+$rowMark['bang_tc']+$rowMark['bang_tf']);
              }

              echo $bang_o;
              ?>
          </td>

          <td rowspan="2"></td>
			<td rowspan="2"></td>
			<td>
			<?php
				if( $rowMark['pelsd_pc']<10 || $rowMark['pelsd_pf']<10 ){
	    				$pelsd_o=0;
	    			}else{
	    			$pelsd_o=(($rowMark['pelsd_pc'])+($rowMark['pelsd_pf']));
	    			}
	    			echo $pelsd_o;
			 ?>
			</td>


		<td rowspan="2">
			<?php
				// $marksheets->toGradeLeter($gpa=$c_gpa);


			 ?>

		</td>
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['registrationNo']; ?></td>
		<td rowspan="2">
		<?php
			countGP($trm1_o,$subjectMark=100);
			 array_push($cgpa,countGP($trm1_o,$subjectMark=100));
			 echo end($cgpa);
		 ?>
		</td>
		<td rowspan="2">
		<?php
			countGP($ed_o,$subjectMark=100);
	            			array_push($cgpa,countGP($ed_o,$subjectMark=100));
	            			echo end($cgpa);

		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($ma1_o,$subjectMark=200); 
	            		 array_push($cgpa,countGP($ma1_o,$subjectMark=200));
	            		 echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($gtp1_o,$subjectMark=200);
    			array_push($cgpa,countGP($gtp1_o,$subjectMark=200));
    			echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($bwp_o,$subjectMark=100);
    		array_push($cgpa,countGP($bwp_o,$subjectMark=100));
    		echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($ch_o,$subjectMark=200);
    		 array_push($cgpa,countGP($ch_o,$subjectMark=200));
    		 echo end($cgpa);
		 ?>
		</td>
        <td rowspan="2">
            <?php
            countGP($bang_o,$subjectMark=150);
            array_push($cgpa,countGP($bang_o,$subjectMark=150));
            echo end($cgpa);
            ?>
        </td>

        <td rowspan="2">
            <?php
            countGP($pelsd_o,$subjectMark=50);
            array_push($cgpa,countGP($pelsd_o,$subjectMark=50));
            echo end($cgpa);
            ?>
        </td>
    </tr>
	<tr>
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['ed_pc'] ?></td>
		<td rowspan="2"><?=$rowMark['ed_pf'] ?></td>
		
		<td rowspan="2"><?=$rowMark['ma1_pc'] ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['gtp1_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['gtp1_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['bwp_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['bwp_pc']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ch_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['ch_pf']; ?></td>

        <td rowspan="2"><?=$rowMark['bang_pc']; ?></td>
        <td rowspan="2"><?=$rowMark['bang_pf']; ?></td>

        <td rowspan="2"><?=$rowMark['pelsd_pc']; ?></td>
        <td rowspan="2"><?=$rowMark['pelsd_pf']; ?></td>
		
		<td rowspan="2">
			<b>
			<?php 
				$c_gpa=0.00;
				if(in_array('0.00',$cgpa)){
					echo "0.00";
				}else{
					$credits=['2','2','4','4','2','4','3', '2'];
					$grandCgpa=[];
					foreach ($cgpa as $key => $value) {
						$grandCgpa[$key]=$value*$credits[$key];
					}
					$c_gpa=round((array_sum($grandCgpa)/23),2);
					echo $c_gpa;	            					
				}
			 ?>
			</b>
		</td>

		<td rowspan="2">
            <?=$marksheets->cgpaToglGenerator($gpa=$c_gpa); ?>
        </td>
		<td rowspan="2">
            <?php
            $counts = array_count_values($cgpa);
            $counts=$counts['0.00'];

            if($counts>2){
                echo "Fail";
            }elseif($counts>=1 && $counts<=2){
                echo "Referred";
            }else{
                echo "Pass";
            }

            ?>
        </td>
	</tr>
	<tr>
		<td class="session-text"><?=$rowMark['session']; ?></td>
		<td><?php countGL($trm1_o,$subjectMark=100); ?></td>		
		<td><?php countGL($ed_o,$subjectMark=100); ?></td>		
		<td><?php countGL($ma1_o,$subjectMark=200); ?></td>		
		<td><?php countGL($gtp1_o,$subjectMark=200); ?></td>		
		<td><?php countGL($bwp_o,$subjectMark=100); ?></td>
		<td><?php countGL($ch_o,$subjectMark=200); ?></td>
		<td><?php countGL($bang_o,$subjectMark=150); ?></td>
		<td><?php countGL($pelsd_o,$subjectMark=50); ?></td>
	</tr>

		<?php
					}
				}else{
				echo '<div class="col-md-5 col-md-offset-3">
		              <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                <h4 class="col-md-4"><i class="icon fa fa-ban"></i> Alert!</h4>
		               NO RECORDS FOUND !
		              </div>        
		            </div>';
				}
		?>



  </table>



<div class="tabulation-buttom">
    <div class="col-xs-12  col-md-12">
        <p>ABBERVIATION: TC - THEORY CONTINUOUS, TF - THEORY FINAL, PC - PRACTICAL CONTINUOUS,PF -  PRACTICAL FINAL, LG - LETTER GRANDE, GP - GRADE</p><br><br>
        
    </div>
    

    <div class="col-xs-5 col-md-5">
        <div class="row">
            <div class="col-xs-6 col-md-5">
                <p>SIGNATURE & DATE OF TABULATOR</p>
            </div>
            <div class="col-xs-6 col-md-7">
                <p>01.........................................................</p>
                <p>02.........................................................</p>
                
            </div>
        </div>
    </div>
    <div class="col-xs-5 col-md-5">
        <div class="row">
            <div class="col-xs-6 col-md-7">
                <P>SIGNATURE & DATE OF COUNCILEOR OF EXAMINAION</P>
            </div>
            <div class="col-xs-6 col-md-5">
                <p>01.........................................................</p>
                <p>02.........................................................</p>
            </div>
        </div>
        
    </div>
    <div class="col-xs-2 col-md-2">
        <div class="row">
            <p></p>
            <p>.........................................................<br>
                PRINCIPAL
            </p>
        </div>
    </div>
</div>

     
        

        <!-- this row will not appear when printing -->
        <div class="row no-print">
          <div class="col-xs-12">
          <!-- <a href="../print/aidtTech.php?roll=<?php //echo $rowMark['roll'];?>" target="_blank" class="btn btn-success pull-right"><i class="fa fa-print"></i> P r i n t</a>  -->
            <button class="btn btn-success pull-right" onclick="printTabulation();">P r i n t </button>         
          </div>
        </div>
  </section>

  <script type="text/javascript">
  	function printTabulation(){
  		window.print();
  	}
  </script>

		
	
	

			
		
		
				

			
