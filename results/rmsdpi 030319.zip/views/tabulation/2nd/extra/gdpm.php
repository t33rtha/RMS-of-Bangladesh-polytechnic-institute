<?php 
require_once('../../../conn/conn.php');
require_once('../../../controllers/class.marksheet.php');

	 
	$startRoll=$_POST['startRoll'];
	$endRoll=$_POST['endRoll'];

	$markSQL="SELECT si.id,si.roll,si.registrationNo,si.name,si.motherName,si.fatherName,t.technologyCode,t.technologyName,s.session,si.shift,sem.semester,
				trm1.tc as trm1_tc,trm1.tf as trm1_tf,
				en2.tc as en2_tc,en2.tf as en2_tf,en2.pc as en2_pc,en2.pf as en2_pf,
				sp.pc as sp_pc,sp.pf as sp_pf,sp.tc as sp_tc,sp.tf as sp_tf,
				ma2.tc as ma2_tc,ma2.tf as ma2_tf,ma2.pc as ma2_pc,								
				phy1.tc as phy1_tc,phy1.tf as phy1_tf,phy1.pc as phy1_pc,phy1.pf as phy1_pf,				
				bwp.pc as bwp_pc,bwp.pf as bwp_pf,
				pelsd.pc as pelsd_pc,pelsd.pf as pelsd_pf
			from studentinformation si 
				LEFT JOIN technology t on t.technologyId=si.technologyId 
				LEFT JOIN session s on s.sessionId=si.sessionId 
				LEFT JOIN semester sem on sem.semesterId=si.semesterId 
				
				LEFT JOIN `5722` en2 on en2.roll=si.roll 
				LEFT JOIN `5921` ma2 on ma2.roll=si.roll 
				LEFT JOIN `5912` phy1 on phy1.roll=si.roll 
				LEFT JOIN `5022` sp on sp.roll=si.roll
				LEFT JOIN `1911` trm1 on trm1.roll=si.roll
				LEFT JOIN `7011` bwp on bwp.roll=si.roll 
				LEFT JOIN `5812` pelsd on pelsd.roll=si.roll 
				WHERE si.roll BETWEEN $startRoll and $endRoll";

	$getHeadingSQL="select std.shift,semester.semester,tech.technologyName,tech.technologyCode,session.session from studentinformation std inner join semester on std.semesterId=semester.semesterId inner join technology tech on tech.technologyId=std.technologyId inner join session on std.sessionId=session.sessionId where roll=$startRoll limit 1";
	$getHeadingResult=mysqli_query($conn,$getHeadingSQL);

	$markResult=mysqli_query($conn,$markSQL);
	$count=$markResult->num_rows;	

	


	function countGP($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			$gp="4.00";
		}else if($currentMarks>=75 && $currentMarks<80) {
			$gp="3.75";
		}else if($currentMarks>=70 && $currentMarks<75) {
			$gp="3.50";
		}else if($currentMarks>=65 && $currentMarks<70) {
			$gp="3.25";
		}else if($currentMarks>=60 && $currentMarks<65) {
			$gp="3.00";
		}else if($currentMarks>=55 && $currentMarks<60) {
			$gp="2.75";
		}else if($currentMarks>=50 && $currentMarks<55) {
			$gp="2.50";
		}else if($currentMarks>=45 && $currentMarks<50) {
			$gp="2.25";
		}else if($currentMarks>=40 && $currentMarks<45) {
			$gp="2.00";
		}else{
			$gp="0.00";
		}

		return $gp;

	}

	function countGL($sum,$subjectMark){

		$currentMarks=(100*$sum)/($subjectMark);
		
		if($currentMarks>=80 && $currentMarks<=100)  {
			echo "A+";
		}else if($currentMarks>=75 && $currentMarks<80) {
			echo "A";
		}else if($currentMarks>=70 && $currentMarks<75) {
			echo "A-";
		}else if($currentMarks>=65 && $currentMarks<70) {
			echo "B+";
		}else if($currentMarks>=60 && $currentMarks<65) {
			echo "B";
		}else if($currentMarks>=55 && $currentMarks<60) {
			echo "B-";
		}else if($currentMarks>=50 && $currentMarks<55) {
			echo "C+";
		}else if($currentMarks>=45 && $currentMarks<50) {
			echo "C";
		}else if($currentMarks>=40 && $currentMarks<45) {
			echo "D";
		}else{
			echo "F";
		}

	}

 ?>

<style type="text/css">
	 .vertical-line{
      width: 1px; /* Line width */
      sc1ckground-color: black; /* Line color */
      height: 100%; /* Override in-line if you want specific height. */
     
    }
</style>
<link rel="stylesheet" type="text/css" href="style.css">

		
<section class="box no-border" style="font-size:12px">
    	<div class="row text-center">
    		<h2 class="no-padding no-margin">Government of the People's Republic of Bangladesh</h2>
    		<h2 class="no-padding no-margin">Tabulation Sheet of Diploma-in-engineering</h2>
    	</div>
    	<div class="row">
    		<?php 
    			while($row=$getHeadingResult->fetch_array(MYSQLI_ASSOC)){    				
    		?>
			<div class="col-sm-8">
    			<div class="form-group no-padding">
    				<span>&nbsp;Technology Code and Name :</span>
    				<label><?=$row['technologyCode']." ".$row['technologyName'];?></label>
    			</div>
    			<div class="form-group no-padding">
    				<span>&nbsp;Institute Code and Name :</span>
    				<label>50328, Daffodil Polytechnic Institute.</label>
    			</div>
    		</div>
    		<div class="col-sm-2 col-sm-offset-2">
    				<span>Semester :</span>
    				<label>
    				<?=$row['semester']; ?>
    				</label><br>
<!--    				<span>Shift :</span>-->
<!--    				<label>-->
    					<?php //echo $marksheets->shiftTotext($sessionValue=$row['shift']); ?>
<!--    				</label><br>-->
    				<span>Examination Year:</span>
    				<label>2018</label>
    		</div>
    		<?php } ?>
    	</div>
      
<!-- <div class="row"> -->
<table class="table table-bordered text-center">
	<tr class="">
        <th colspan="2">Student's Identity</th>
        <th colspan="3">Basic Workshop Practice<br>(7011)</th>
        <th colspan="3">English-II<br>(5722)</th>
        <th colspan="3">Mathmatics-2<br>(5921)</th>
        <th colspan="3">physics-1(5912)</th>
        <th colspan="3">Textile Raw Materials-I<br>(1911)</th>
        <th colspan="3">Sewing Practice<br>(5022)</th>
        <th colspan="3">Physical Education,<br>Life Skill Dev.(5812)</th>
		
		<th>Grade Point<br>Avg.</th>
		<th>Grade Letter<br>Avg.</th>
		<th>Remark</th>
		<style type="text/css">
			table.table-bordered{
			    border:2px solid #ddd;			    
			  }
			table.table-bordered > thead > tr > th{
			    border:2px solid #ddd;
			}
			table.table-bordered > tbody > tr > th{
			    border:2px solid #ddd;
			}
			table.table-bordered > tbody > tr > td{
			    border:2px solid #ddd;
			}
		</style>

	</tr>
	<tr>
		<td>Roll</td>
		<td class="std-name" rowspan="4">Student's Name</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>
		<td>Total</td>
		<td rowspan="2">TC</td>
		<td rowspan="2">TF</td>		
		<td>Total</td>

        <td rowspan="2">TC</td>
        <td rowspan="2">TF</td>
        <td>Total</td>
        
		<td rowspan="4">GPA</td>
		<td rowspan="4">GLA</td>
		<td rowspan="4">pass<br>/fail</td>
	</tr>
	<tr>
		<td rowspan="2">Regi</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>		
		<td rowspan="2">GP</td>			
		<td rowspan="2">GP</td>
	</tr>
	<tr>
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
		
		<td rowspan="2">PC</td>
		<td rowspan="2">PF</td>
        <td rowspan="2">PC</td>
        <td rowspan="2">PF</td>

		<!-- <td rowspan="2">GPA</td> -->
	</tr>
	<tr>
		<td>Session</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>		
		<td>GL</td>
	</tr>



    
    				<!-- loop start from here -->
    <?php 
		if(isset($count) && $count>0){

		while ($rowMark=$markResult->fetch_assoc()) {			
		$m_o=0;
		$cgpa=array();
	?>	
    
      <tr>
		<td><?=$rowMark['roll']; ?></td>
		<td rowspan="4"><?=$rowMark['name']; ?></td>
		<td rowspan="2"></td>
		<td rowspan="2"></td>
		<td>
			<?php 
				if($rowMark['bwp_pc']<20 || $rowMark['bwp_pf']<20){
					$bwp_o=0;
				}else{
					$bwp_o=(($rowMark['bwp_pc'])+($rowMark['bwp_pf']));
				}	            				
				echo $bwp_o;
			 ?>
		</td>
		<td rowspan="2"><?=$rowMark['en2_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['en2_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['en2_tc']<8 || $rowMark['en2_tf']<32 || $rowMark['en2_pc']<10 || $rowMark['en2_pf']<10){
    				$en2_o=0;
    			}else{
    				$en2_o=($rowMark['en2_tc']+$rowMark['en2_tf']+$rowMark['en2_pc']+$rowMark['en2_pf']);
    			}	            			
    			echo $en2_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['ma2_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['ma2_tf']; ?></td>
		<td>
		<?php 
			if($rowMark['ma2_tc']<12 || $rowMark['ma2_tf']<48 || $rowMark['ma2_pc']<20){
    				$ma2_o=0;
    			}else{
    			$ma2_o=(($rowMark['ma2_tc'])+($rowMark['ma2_tf'])+($rowMark['ma2_pc']));
    			}	            			
    			echo $ma2_o;
		 ?>
		</td>
		<td rowspan="2"><?=$rowMark['phy1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy1_tf']; ?></td>
		<td>
			<?php 
				if($rowMark['phy1_tc']<12 || $rowMark['phy1_tf']<48 || $rowMark['phy1_pc']<10 ||
                    $rowMark['phy1_pf']<10){
    				$phy1_o=0;
    			}else{
    				$phy1_o=(($rowMark['phy1_tc'])+($rowMark['phy1_tf'])+($rowMark['phy1_pc'])+($rowMark['phy1_pf']));
    			}	            				
    			echo $phy1_o;


			 ?>
		</td>

		<td rowspan="2"><?=$rowMark['trm1_tc']; ?></td>
		<td rowspan="2"><?=$rowMark['trm1_tf']; ?></td>
		<td>
			<?php 
			
			if($rowMark['trm1_tc']<8 || $rowMark['trm1_tf']<32){
				$trm1_o=0;
			}else{
				$trm1_o=(($rowMark['trm1_tc']+$rowMark['trm1_tf']));
			}

			
			echo $trm1_o;
			 ?>
		</td>

          <td rowspan="2"><?=$rowMark['sp_tc']; ?></td>
          <td rowspan="2"><?=$rowMark['sp_tf']; ?></td>
		<td>
			<?php 
				if($rowMark['sp_tc']<8 || $rowMark['sp_tf']<32 || $rowMark['sp_pc']<20 || $rowMark['sp_pf']<20 ){
    				$sp_o=0;
    			}else{
    				$sp_o=($rowMark['sp_pc']+$rowMark['sp_pf']+$rowMark['sp_tc']+$rowMark['sp_tf']);
    			}
    				            				
    			echo $sp_o;
			 ?>
		</td>

          <td rowspan="2"></td>
          <td rowspan="2"></td>
          <td>
              <?php
              if( $rowMark['pelsd_pc']<10 || $rowMark['pelsd_pf']<10){
                  $pelsd_o=0;
              }else{
                  $pelsd_o=($rowMark['pelsd_pc']+$rowMark['pelsd_pf']);
              }

              echo $pelsd_o;
              ?>
          </td>


		<td rowspan="2">
			<?php 
				// $marksheets->toGradeLeter($gpa=$c_gpa);


			 ?>
			
		</td>
	</tr>
	<tr>
		<td rowspan="2"><?=$rowMark['registrationNo']; ?></td>		
		<td rowspan="2">
		<?php 
			countGP($bwp_o,$subjectMark=100);
			 array_push($cgpa,countGP($bwp_o,$subjectMark=100));
			 echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($en2_o,$subjectMark=150);
	            			array_push($cgpa,countGP($en2_o,$subjectMark=150));
	            			echo end($cgpa);

		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($ma2_o,$subjectMark=200); 
	            		 array_push($cgpa,countGP($ma2_o,$subjectMark=200));
	            		 echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
			<?php 
    			countGP($phy1_o,$subjectMark=200);
    			array_push($cgpa,countGP($phy1_o,$subjectMark=200));
    			echo end($cgpa);
    		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($trm1_o,$subjectMark=100);
    		array_push($cgpa,countGP($trm1_o,$subjectMark=100));
    		echo end($cgpa);
		 ?>
		</td>		
		<td rowspan="2">
		<?php 
			countGP($sp_o,$subjectMark=200);
    		 array_push($cgpa,countGP($sp_o,$subjectMark=200));
    		 echo end($cgpa);
		 ?>
		</td>
        <td rowspan="2">
            <?php
            countGP($pelsd_o,$subjectMark=50);
            array_push($cgpa,countGP($pelsd_o,$subjectMark=50));
            echo end($cgpa);
            ?>
        </td>
    </tr>
	<tr>
		<td rowspan="2"><?=$rowMark['bwp_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['bwp_pf']; ?></td>

        <td rowspan="2"><?=$rowMark['en2_pc']; ?></td>
        <td rowspan="2"><?=$rowMark['en2_pf']; ?></td>
		
		<td rowspan="2"><?=$rowMark['ma2_pc'] ?></td>
		<td rowspan="2"></td>
		
		<td rowspan="2"><?=$rowMark['phy1_pc']; ?></td>
		<td rowspan="2"><?=$rowMark['phy1_pf']; ?></td>

        <td rowspan="2"></td>
        <td rowspan="2"></td>

        <td rowspan="2"><?=$rowMark['sp_pc']; ?></td>
        <td rowspan="2"><?=$rowMark['sp_pf']; ?></td>

        <td rowspan="2"><?=$rowMark['pelsd_pc']; ?></td>
        <td rowspan="2"><?=$rowMark['pelsd_pf']; ?></td>
		
		<td rowspan="2">
			<b>
			<?php 
				$c_gpa=0.00;
				if(in_array('0.00',$cgpa)){
					echo "0.00";
				}else{
					$credits=['2','3','4','4','2','4','1'];
					$grandCgpa=[];
					foreach ($cgpa as $key => $value) {
						$grandCgpa[$key]=$value*$credits[$key];
					}
					$c_gpa=round((array_sum($grandCgpa)/20),2);
					echo $c_gpa;	            					
				}
			 ?>
			</b>
		</td>

		<td rowspan="2">
            <?=$marksheets->cgpaToglGenerator($gpa=$c_gpa); ?>
        </td>
		<td rowspan="2">
            <?php
            $counts = array_count_values($cgpa);
            $counts=$counts['0.00'];

            if($counts>2){
                echo "Fail";
            }elseif($counts>=1 && $counts<=2){
                echo "Referred";
            }else{
                echo "Pass";
            }

            ?>
        </td>

	</tr>
	<tr>
		<td class="session-text"><?=$rowMark['session']; ?></td>
		<td><?php countGL($bwp_o,$subjectMark=100); ?></td>		
		<td><?php countGL($en2_o,$subjectMark=150); ?></td>		
		<td><?php countGL($ma2_o,$subjectMark=200); ?></td>		
		<td><?php countGL($phy1_o,$subjectMark=200); ?></td>		
		<td><?php countGL($trm1_o,$subjectMark=100); ?></td>
		<td><?php countGL($sp_o,$subjectMark=200); ?></td>
		<td><?php countGL($pelsd_o,$subjectMark=50); ?></td>
	</tr>

		<?php
					}
				}else{
				echo '<div class="col-md-5 col-md-offset-3">
		              <div class="alert alert-danger alert-dismissible">
		                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		                <h4 class="col-md-4"><i class="icon fa fa-sc1n"></i> Alert!</h4>
		               NO RECORDS FOUND !
		              </div>        
		            </div>';
				}
		?>



  </table>



<div class="tabulation-buttom">
	<div class="col-md-12">
		<p>ABBERVIATION: TC - THEORY CONTINUOUS, TF - THEORY FINAL, PC - PRACTICAL CONTINUOUS,PF -  PRACTICAL FINAL, LG - LETTER GRANDE, GP - GRADE</p>
		
	</div>
	

	<div class="col-md-5">
		<div class="row">
			<div class="col-md-5">
				<p>SIGNATURE & DATE OF TABULATOR</p>
			</div>
			<div class="col-md-7">
				<p>01.........................................................</p>
				<p>02.........................................................</p>
				
			</div>
		</div>
	</div>
	<div class="col-md-5">
		<div class="row">
			<div class="col-md-7">
				<P>SIGNATURE & DATE OF COUNCILEOR OF EXAMINAION</P>
			</div>
			<div class="col-md-5">
				<p>01.........................................................</p>
				<p>02.........................................................</p>
			</div>
		</div>
		
	</div>
	<div class="col-md-2">
		<div class="row">
			<p></p>
			<p>.........................................................<br>
				PRINCIPAL
			</p>
		</div>
	</div>
</div>
     
        

        <!-- this row will not appear when printing -->
        <div class="row no-print">
          <div class="col-xs-12">
          <!-- <a href="../print/aidtTech.php?roll=<?php //echo $rowMark['roll'];?>" target="_blank" class="btn btn-success pull-right"><i class="fa fa-print"></i> P r i n t</a>  -->
            <button class="btn btn-success pull-right" onclick="printTabulation();">P r i n t </button>         
          </div>
        </div>
  </section>

  <script type="text/javascript">
  	function printTabulation(){
  		window.print();
  	}
  </script>

		
	
	

			
		
		
				

			
